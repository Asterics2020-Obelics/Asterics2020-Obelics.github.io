'''
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
'''

'''{
We need also to import several packages :

\begin{itemize}
	\item \textbf{sys} : to make an output compatible with C++ performances output
	\item \textbf{numpy} : to deal with arrays
	\item \textbf{astericshpc} : to allocate arrays and do the performance test
\end{itemize}
}'''

import sys
import astericshpc
import hadamardpython

'''{
The function to initialise tables :
}'''

def allocInitTable(nbElement):
	tab = astericshpc.allocTable(nbElement)
	for i in range(0, nbElement):
		tab[i] = float(i*32%17)
	return tab

'''{
The function to evaluate performances is built the same way such as the C++ one :
}'''

def getTimeFunctionSize(nbRepetition, nbElement):
	tabX = allocInitTable(nbElement)
	tabY = allocInitTable(nbElement)
	tabRes = astericshpc.allocTable(nbElement)
	
	timeBegin = astericshpc.rdtsc()
	for i in range(0, nbRepetition):
		hadamardpython.hadamard(tabRes, tabX, tabY)
	
	timeEnd = astericshpc.rdtsc()
	elapsedTime = float(timeEnd - timeBegin)/float(nbRepetition)
	elapsedTimePerElement = elapsedTime/float(nbElement)
	print("nbElement =",nbElement,", elapsedTimePerElement =",elapsedTimePerElement,"cy/el",", elapsedTime =",elapsedTime,"cy")
	print(str(nbElement) + "\t" + str(elapsedTimePerElement) + "\t" + str(elapsedTime),file=sys.stderr)

'''{
Then, we have a function to make all the points with a list of sizes :
}'''

def makeElapsedTimeValue(listSize, nbRepetition):
	for val in listSize:
		getTimeFunctionSize(nbRepetition, val)

'''{
Finally, we call the performances tests only if this script is executed as a main file and not if it is included by an other file :
}'''

if __name__ == "__main__":
	listSize = [1000,
			1600,
			2000,
			2400,
			2664,
			3000,
			4000,
			5000,
			10000]
	makeElapsedTimeValue(listSize, 10000000)




