/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/


#include "sgemm.h"

///Compute the Matrix-Matrix product of the x,y matrices
/**	@param[out] matOut : result
 * 	@param matX : left matrix
 * 	@param matY : right matrix
 * 	@param size : size of the square matrices
*/
void sgemm(float* matOut, const float * matX, const float* matY, long unsigned int size){
	for(long unsigned int i(0lu); i < size; ++i){
		for(long unsigned int j(0lu); j < size; ++j){
			float res(0.0f);
			for(long unsigned int k(0lu); k < size; ++k){
				res += matX[i*size + k]*matY[k*size + j];
			}
			matOut[i*size + j] = res;
		}
	}
}



