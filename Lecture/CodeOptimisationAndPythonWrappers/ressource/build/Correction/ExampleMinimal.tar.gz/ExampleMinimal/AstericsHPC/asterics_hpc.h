/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#ifndef __ASTERICS_HPC_H__
#define __ASTERICS_HPC_H__

#include "timer.h"
#include "asterics_alloc.h"

#endif

