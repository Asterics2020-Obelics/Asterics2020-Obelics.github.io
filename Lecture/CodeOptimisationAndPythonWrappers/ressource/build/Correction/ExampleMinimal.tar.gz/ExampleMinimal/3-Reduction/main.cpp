/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

/*{
First, we have to include the appropriate files :
}*/

#include <iostream>
#include "asterics_hpc.h"

using namespace std;

/*{
Then, we define our reduction kernel :
}*/

///Do the reduction
/**	@param tabValue : input table
 * 	@param nbElement : number of elements in the input table
 * 	@return sum of all the elements of the input table
*/
float reduction(const float * tabValue, long unsigned int nbElement){
	float res(0.0f);
	for(long unsigned int i(0lu); i < nbElement; ++i){
		res += tabValue[i];
	}
	return res;
}

/*{
We add the function to evaluate our kernel :
}*/

///Get the number of cycles per elements of the reduction
/**	@param nbElement : number of elements of the tables
 * 	@param nbRepetition : number of repetition to evaluate the function reduction
*/
void evaluateReduction(long unsigned int nbElement, long unsigned int nbRepetition){
	float * tabValue = (float*)asterics_malloc(sizeof(float)*nbElement);
	for(long unsigned int i(0lu); i < nbElement; ++i){
		tabValue[i] = (float)(i*32lu%17lu);
	}
	
	long unsigned int beginTime(rdtsc());
	for(long unsigned int i(0lu); i < nbRepetition; ++i){
		//We do not used the result of the function, so GCC7 deduces that this loop is useless and do not compile the code except in -O0 mode
		reduction(tabValue, nbElement);
	}
	long unsigned int elapsedTime((double)(rdtsc() - beginTime)/((double)nbRepetition));
	
	double cyclePerElement(((double)elapsedTime)/((double)nbElement));
	cout << "evaluateReduction : nbElement = "<<nbElement<<", cyclePerElement = " << cyclePerElement << " cy/el, elapsedTime = " << elapsedTime << " cy" << endl;
	cerr << nbElement << "\t" << cyclePerElement << "\t" << elapsedTime << endl;
	
	asterics_free(tabValue);
}

/*{
Finally, we call the function to evaluate several points in order to make plots :
}*/

int main(int argc, char** argv){
	cout << "Reduction" << endl;
	evaluateReduction(1000lu, 1000000lu);
	evaluateReduction(2000lu, 1000000lu);
	evaluateReduction(3000lu, 1000000lu);
	evaluateReduction(5000lu, 1000000lu);
	evaluateReduction(10000lu, 1000000lu);
	return 0;
}

