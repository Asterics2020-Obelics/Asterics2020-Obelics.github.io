'''
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
'''

'''{
We need also to import several packages :

\begin{itemize}
	\item \textbf{sys} : to make an output compatible with C++ performances output
	\item \textbf{numpy} : to deal with arrays
	\item \textbf{astericshpc} : to allocate arrays and do the performance test
\end{itemize}
}'''

import sys
import numpy as np
import astericshpc

'''{
The function to evaluate performances is built the same way such as the C++ one :
}'''

def getTimeFunctionSize(nbRepetition, nbElement):
	tabX = np.asarray(np.random.random(nbElement), dtype=np.float32)
	
	timeBegin = astericshpc.rdtsc()
	for i in range(0, nbRepetition):
		res = tabX.sum()
	
	timeEnd = astericshpc.rdtsc()
	elapsedTime = float(timeEnd - timeBegin)/float(nbRepetition)
	elapsedTimePerElement = elapsedTime/float(nbElement)
	print("nbElement =",nbElement,", elapsedTimePerElement =",elapsedTimePerElement,"cy/el",", elapsedTime =",elapsedTime,"cy")
	print(str(nbElement) + "\t" + str(elapsedTimePerElement) + "\t" + str(elapsedTime),file=sys.stderr)

'''{
Then, we have a function to make all the points with a list of sizes :
}'''

def makeElapsedTimeValue(listSize, nbRepetition):
	for val in listSize:
		getTimeFunctionSize(nbRepetition, val)

'''{
Finally, we call the performances tests only if this script is executed as a main file and not if it is included by an other file :
}'''

if __name__ == "__main__":
	listSize = [	1024,
			2048,
			3072,
			4992,
			10048]
	makeElapsedTimeValue(listSize, 1000000)




