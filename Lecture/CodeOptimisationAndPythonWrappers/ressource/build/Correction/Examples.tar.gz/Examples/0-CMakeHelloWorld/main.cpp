#include <iostream>

int main(int argc, char** argv){
	std::cerr << "Hello world" << std::endl;
	return 0;
}

