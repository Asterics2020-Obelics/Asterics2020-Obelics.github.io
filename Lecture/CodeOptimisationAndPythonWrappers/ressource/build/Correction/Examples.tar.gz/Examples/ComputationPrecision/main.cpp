/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#include <iostream>
#include "asterics_alloc.h"
#include "reduction_intrinsics_interleave8.h"

using namespace std;

///Do the reduction with float
/**	@param tabFloat : table of float to be reduced
 * 	@param nbElement : number of elements of the input table
 * 	@return sum of all elements
*/
float reductionFloat(float* tabFloat, size_t nbElement){
	float res(0.0f);
	for(size_t i(0lu); i < nbElement; ++i){
		res += tabFloat[i];
	}
	return res;
}

///Do the reduction with float
/**	@param tabFloat : table of float to be reduced
 * 	@param nbElement : number of elements of the input table
 * 	@return sum of all elements
*/
double reductionDouble(double* tabFloat, size_t nbElement){
	double res(0.0f);
	for(size_t i(0lu); i < nbElement; ++i){
		res += tabFloat[i];
	}
	return res;
}

///Compute the relative error with float
/**	@param ref : reference value
 * 	@param val : val to be tested
 * 	@return relative error
*/
float deltaRelatifFloat(float ref, float val){
	return (val - ref)/ref;
}

///Compute the relative error with float
/**	@param ref : reference value
 * 	@param val : val to be tested
 * 	@return relative error
*/
double deltaRelatifDouble(double ref, double val){
	return (val - ref)/ref;
}

///Test precision of a reduction
void reductionPrecision(){
	size_t nbElement(10048lu);
	float raisonFloat(10.f), u0float(32.f);
	double raisonDouble(raisonFloat), u0Double(u0float);
	float* tabFloat = (float*)asterics_malloc(nbElement*sizeof(float));
	double* tabDouble = new double[nbElement];
	for(size_t i(0lu); i < nbElement; ++i){
		tabFloat[i] = u0float + ((float)i)*raisonFloat;
		tabDouble[i] = u0Double + ((double)i)*raisonDouble;
	}
	
	float sumExactFloat((((float)nbElement + 1lu)*(2.0f*u0float + ((float)nbElement)*raisonFloat))/2.0f);
	float sumExactDouble((((double)nbElement + 1lu)*(2.0*u0Double + ((double)nbElement)*raisonDouble))/2.0);
	
	cout << "sumExactFloat = " << sumExactFloat << endl;
	cout << "sumExactDouble = " << sumExactDouble << endl;
	
	float resFloat(reductionFloat(tabFloat, nbElement));
	cout << "resFloat = " << resFloat << ", relative error = " << deltaRelatifFloat(sumExactFloat, resFloat) << endl;
	double resDouble(reductionDouble(tabDouble, nbElement));
	cout << "resDouble = " << resDouble << ", relative error = " << deltaRelatifDouble(sumExactDouble, resDouble) << endl;
	
	float resIntrinsics(reduction(tabFloat, nbElement));
	cout << "resIntrinsics = " << resIntrinsics << ", relative error = " << deltaRelatifFloat(sumExactFloat, resIntrinsics) << endl;
	
	delete [] tabDouble;
	asterics_free(tabFloat);
}


int main(int argc, char** argv){
	reductionPrecision();
	
	return 0;
}

