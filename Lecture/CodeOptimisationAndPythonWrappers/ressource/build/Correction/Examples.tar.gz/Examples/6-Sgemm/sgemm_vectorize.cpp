/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#include <string.h>
#include "sgemm_swap.h"

///Compute the Matrix-Matrix product of the x,y matrices
/**	@param[out] pmatOut : result
 * 	@param pmatX : left matrix
 * 	@param pmatY : right matrix
 * 	@param size : size of the square matrices
*/
void sgemm(float* __restrict__ pmatOut, const float* __restrict__ pmatX, const float* __restrict__ pmatY, long unsigned int size){
	const float* matX = (const float*)__builtin_assume_aligned(pmatX, VECTOR_ALIGNEMENT);
	const float* matY = (const float*)__builtin_assume_aligned(pmatY, VECTOR_ALIGNEMENT);
	float* matOut = (float*)__builtin_assume_aligned(pmatOut, VECTOR_ALIGNEMENT);
	
	memset(matOut, 0, sizeof(float)*size*size);
	for(long unsigned int i(0lu); i < size; ++i){
		for(long unsigned int k(0lu); k < size; ++k){
			for(long unsigned int j(0lu); j < size; ++j){
				matOut[i*size + j] += matX[i*size + k]*matY[k*size + j];
			}
		}
	}
}

