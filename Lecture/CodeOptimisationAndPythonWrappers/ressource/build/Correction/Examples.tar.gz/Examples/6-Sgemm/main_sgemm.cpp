/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#include <iostream>
#include "asterics_hpc.h"
#include "sgemm.h"

using namespace std;

///Get the number of cycles per elements of the reduction
/**	@param nbElement : number of elements of the tables
 * 	@param nbRepetition : number of repetition to evaluate the function reduction
*/
void evaluateSgemm(long unsigned int nbElement, long unsigned int nbRepetition){
	float * matX = (float*)asterics_malloc(sizeof(float)*nbElement*nbElement);
	float * matY = (float*)asterics_malloc(sizeof(float)*nbElement*nbElement);
	float * matOut = (float*)asterics_malloc(sizeof(float)*nbElement*nbElement);
	
	for(long unsigned int i(0lu); i < nbElement*nbElement; ++i){
		matX[i] = (float)(i*32lu%17lu);
		matY[i] = (float)(i*77lu%31lu);
	}
	long unsigned int beginTime(rdtsc());
	for(long unsigned int i(0lu); i < nbRepetition; ++i){
		sgemm(matOut, matX, matY, nbElement);
	}
	long unsigned int elapsedTime((double)(rdtsc() - beginTime)/((double)nbRepetition));
	
	double cyclePerElement(((double)elapsedTime)/((double)(nbElement*nbElement)));
	cout << "evaluateSgemm : nbElement = "<<nbElement<<", cyclePerElement = " << cyclePerElement << " cy/el, elapsedTime = " << elapsedTime << " cy" << endl;
	cerr << nbElement << "\t" << cyclePerElement << "\t" << elapsedTime << endl;
	
	asterics_free(matOut);
	asterics_free(matY);
	asterics_free(matX);
}

int main(int argc, char** argv){
	cout << "SGEMM" << endl;
	evaluateSgemm(10lu, 100000lu);
	evaluateSgemm(20lu, 100000lu);
	evaluateSgemm(30lu, 100000lu);
	evaluateSgemm(50lu, 10000lu);
	evaluateSgemm(80lu, 10000lu);
	evaluateSgemm(100lu, 10000lu);
	return 0;
}

