/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#ifndef __SGEMM_SWAP_H__
#define __SGEMM_SWAP_H__


void sgemm(float* matOut, const float * matX, const float* matY, long unsigned int size);



#endif
