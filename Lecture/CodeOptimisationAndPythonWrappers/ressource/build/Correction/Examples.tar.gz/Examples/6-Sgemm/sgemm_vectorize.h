/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#ifndef __SGEMM_VECTORIZE_H__
#define __SGEMM_VECTORIZE_H__


void sgemm(float* __restrict__ pmatOut, const float* __restrict__ pmatX, const float* __restrict__ pmatY, long unsigned int size);



#endif
