/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#ifndef __BARYCENTRE_VECTORIZE_SPLIT_H__
#define __BARYCENTRE_VECTORIZE_SPLIT_H__


void barycentre(float & gx, float & gy, const float * __restrict__ ptabX, const float* __restrict__ ptabY, const float* __restrict__ ptabA, long unsigned int nbElement);



#endif
