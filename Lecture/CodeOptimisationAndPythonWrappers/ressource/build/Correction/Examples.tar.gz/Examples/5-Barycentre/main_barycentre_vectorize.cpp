/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#include <iostream>
#include "asterics_hpc.h"
#include "barycentre_vectorize.h"

using namespace std;

///Get the number of cycles per elements of the reduction
/**	@param nbElement : number of elements of the tables
 * 	@param nbRepetition : number of repetition to evaluate the function reduction
*/
void evaluateBarycentre(long unsigned int nbElement, long unsigned int nbRepetition){
	float * tabX = (float*)asterics_malloc(sizeof(float)*nbElement);
	float * tabY = (float*)asterics_malloc(sizeof(float)*nbElement);
	float * tabA = (float*)asterics_malloc(sizeof(float)*nbElement);
	
	for(long unsigned int i(0lu); i < nbElement; ++i){
		tabX[i] = (float)(i*32lu%17lu);
		tabY[i] = (float)(i*77lu%31lu);
		tabA[i] = (float)(i*73lu%27lu);
	}
	float gx(0.0f), gy(0.0f);
	long unsigned int beginTime(rdtsc());
	for(long unsigned int i(0lu); i < nbRepetition; ++i){
		barycentre(gx, gy, tabX, tabY, tabA, nbElement);
	}
	long unsigned int elapsedTime((double)(rdtsc() - beginTime)/((double)nbRepetition));
	
	double cyclePerElement(((double)elapsedTime)/((double)nbElement));
	cout << "evaluateBarycentre : nbElement = "<<nbElement<<", cyclePerElement = " << cyclePerElement << " cy/el, elapsedTime = " << elapsedTime << " cy" << endl;
	cerr << nbElement << "\t" << cyclePerElement << "\t" << elapsedTime << endl;
	
	asterics_free(tabA);
	asterics_free(tabY);
	asterics_free(tabX);
}

int main(int argc, char** argv){
	cout << "Barycentre vectorize" << endl;
	evaluateBarycentre(1000lu, 100000lu);
	evaluateBarycentre(2000lu, 100000lu);
	evaluateBarycentre(3000lu, 100000lu);
	evaluateBarycentre(5000lu, 100000lu);
	evaluateBarycentre(10000lu, 100000lu);
	return 0;
}

