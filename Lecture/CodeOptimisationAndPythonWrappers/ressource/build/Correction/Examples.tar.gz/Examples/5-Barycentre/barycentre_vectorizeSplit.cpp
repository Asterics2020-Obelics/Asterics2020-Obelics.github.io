/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/


#include "barycentre_vectorize.h"

///Compute the barycentre of the x,y,a tables
/**	@param[out] gx : barycentre on X axis
 * 	@param[out] gy : barycentre on Y axis
 * 	@param ptabX : coordinates on X axis
 * 	@param ptabY : coordinates on Y axis
 * 	@param ptabA : signal amplitude
 * 	@param nbElement : number of elements of the input tables
*/
void barycentre(float & gx, float & gy, const float * __restrict__ ptabX, const float* __restrict__ ptabY, const float* __restrict__ ptabA, long unsigned int nbElement){
	const float* tabX = (const float*)__builtin_assume_aligned(ptabX, VECTOR_ALIGNEMENT);
	const float* tabY = (const float*)__builtin_assume_aligned(ptabY, VECTOR_ALIGNEMENT);
	const float* tabA = (const float*)__builtin_assume_aligned(ptabA, VECTOR_ALIGNEMENT);
	
	gx = 0.0f;
	gy = 0.0f;
	for(long unsigned int i(0lu); i < nbElement; ++i){
		gx += tabX[i]*tabA[i];
	}
	for(long unsigned int i(0lu); i < nbElement; ++i){
		gy += tabY[i]*tabA[i];
	}
	gx /= (float)nbElement;
	gy /= (float)nbElement;
}

