/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#ifndef __BARYCENTRE_VECTORIZE_INTRINSICS_H__
#define __BARYCENTRE_VECTORIZE_INTRINSICS_H__


void barycentre(float & gx, float & gy, const float * tabX, const float* tabY, const float* tabA, long unsigned int nbElement);



#endif
