/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/


#include "barycentre.h"

///Compute the barycentre of the x,y,a tables
/**	@param[out] gx : barycentre on X axis
 * 	@param[out] gy : barycentre on Y axis
 * 	@param tabX : coordinates on X axis
 * 	@param tabY : coordinates on Y axis
 * 	@param tabA : signal amplitude
 * 	@param nbElement : number of elements of the input tables
*/
void barycentre(float & gx, float & gy, const float * tabX, const float* tabY, const float* tabA, long unsigned int nbElement){
	gx = 0.0f;
	gy = 0.0f;
	for(long unsigned int i(0lu); i < nbElement; ++i){
		gx += tabX[i]*tabA[i];
		gy += tabY[i]*tabA[i];
	}
	gx /= (float)nbElement;
	gy /= (float)nbElement;
}

