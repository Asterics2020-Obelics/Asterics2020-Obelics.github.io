/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#include <stdlib.h>
#include <iostream>
#include "asterics_hpc.h"

using namespace std;

///Get a random number between 0 and 1
/**	@return random number between 0 and 1
*/
float randFloat(){
	return ((float)rand())/((float)RAND_MAX);
}

///Do the dummy copy
/**	@param[out] tabResult : table of results of tabX*tabY
 * 	@param tabX : input table
 * 	@param tabY : input table
 * 	@param tabProba : table of probability
 * 	@param nbElement : number of elements in the tables
 * 	@param proba : probability to copy tabX in tabResult
*/
void dummyCopy(float* tabResult, const float * tabX, const float* tabY, const float * tabProba, long unsigned int nbElement, float proba){
	for(long unsigned int i(0lu); i < nbElement; ++i){
		float cond(tabProba[i] < proba);
		tabResult[i] = tabX[i]*cond + (1.0f - cond)*tabY[i];	//Equivalent condition but without branching
	}
}

///Get the number of cycles per elements of the saxpy
/**	@param proba : probability to copy a value in the table X 
 * 	@param nbRepetition : number of repetition to evaluate the function saxpy
*/
void evaluateDummyCopy(float proba, long unsigned int nbRepetition){
	long unsigned int nbElement(10000lu);
	float * tabResult = (float*)asterics_malloc(sizeof(float)*nbElement);
	float * tabX = (float*)asterics_malloc(sizeof(float)*nbElement);
	float * tabY = (float*)asterics_malloc(sizeof(float)*nbElement);
	float * tabProba = (float*)asterics_malloc(sizeof(float)*nbElement);
	
	for(long unsigned int i(0lu); i < nbElement; ++i){
		tabX[i] = (float)(i*32lu%17lu);
		tabY[i] = (float)(i*57lu%31lu);
		tabProba[i] = randFloat();
	}
	
	long unsigned int beginTime(rdtsc());
	for(long unsigned int i(0lu); i < nbRepetition; ++i){
		dummyCopy(tabResult, tabX, tabY, tabProba, nbElement, proba);
	}
	long unsigned int elapsedTime((double)(rdtsc() - beginTime)/((double)nbRepetition));
	
	double cyclePerElement(((double)elapsedTime)/((double)nbElement));
	cout << "evaluateDummyCopy : proba = "<<proba<<", nbElement = "<<nbElement<<", cyclePerElement = " << cyclePerElement << " cy/el, elapsedTime = " << elapsedTime << " cy" << endl;
	cerr << proba << "\t" << cyclePerElement << "\t" << elapsedTime << endl;
	
	asterics_free(tabProba);
	asterics_free(tabResult);
	asterics_free(tabX);
	asterics_free(tabY);
}

int main(int argc, char** argv){
	cout << "Branching probability no branching" << endl;
	evaluateDummyCopy(0.1f, 10000lu);
	evaluateDummyCopy(0.2f, 10000lu);
	evaluateDummyCopy(0.3f, 10000lu);
	evaluateDummyCopy(0.4f, 10000lu);
	evaluateDummyCopy(0.5f, 10000lu);
	evaluateDummyCopy(0.6f, 10000lu);
	evaluateDummyCopy(0.7f, 10000lu);
	evaluateDummyCopy(0.8f, 10000lu);
	evaluateDummyCopy(0.9f, 10000lu);
	return 0;
}

