/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#include <immintrin.h>

#include <stdlib.h>
#include <iostream>
#include "asterics_hpc.h"

#define CMP_LOWER_THAN 1
#define CMP_GREATER_EQUAL_THAN 4

using namespace std;

///Get a random number between 0 and 1
/**	@return random number between 0 and 1
*/
float randFloat(){
	return ((float)rand())/((float)RAND_MAX);
}

///Do the dummy copy
/**	@param[out] tabResult : table of results of tabX*tabY
 * 	@param tabX : input table
 * 	@param tabY : input table
 * 	@param tabProba : table of probability
 * 	@param nbElement : number of elements in the tables
 * 	@param proba : probability to copy tabX in tabResult
*/
void dummyCopy(float* tabResult, const float * tabX, const float* tabY,
		const float * tabProba, long unsigned int nbElement, float proba)
{
	long unsigned int vecSize(VECTOR_ALIGNEMENT/sizeof(float));
	long unsigned int nbVec(nbElement/vecSize);
	register __m256 vecThres = _mm256_broadcast_ss(&proba);
	
	for(long unsigned int i(0lu); i < nbVec; ++i){
		__m256 vecProb = _mm256_load_ps(tabProba + i*vecSize);
		__m256i vecX = (__m256i)_mm256_load_ps(tabX + i*vecSize);
		__m256i vecCondLower = (__m256i)_mm256_cmp_ps(vecProb, vecThres, CMP_LOWER_THAN);	//Return a mask with 00000000 or 11111111
		register __m256i vecAndLower = _mm256_and_si256(vecX, vecCondLower);
		
		__m256i vecY = (__m256i)_mm256_load_ps(tabY + i*vecSize);
		__m256i vecCondGreater = (__m256i)_mm256_cmp_ps(vecProb, vecThres, CMP_GREATER_EQUAL_THAN);	//Return a mask with 00000000 or 11111111
		__m256i vecAndGreater = _mm256_and_si256(vecY, vecCondGreater);
		
		__m256 vecRes = (__m256)_mm256_or_si256(vecAndLower, vecAndGreater);
		_mm256_store_ps(tabResult + i*vecSize, vecRes);
		
// 		float cond(tabProba[i] < proba);
// 		tabResult[i] = tabX[i]*cond + (1.0f - cond)*tabY[i];	//Equivalent condition but without branching
	}
}

///Get the number of cycles per elements of the saxpy
/**	@param proba : probability to copy a value in the table X 
 * 	@param nbRepetition : number of repetition to evaluate the function saxpy
*/
void evaluateDummyCopy(float proba, long unsigned int nbRepetition){
	long unsigned int nbElement(10000lu);
	float * tabResult = (float*)asterics_malloc(sizeof(float)*nbElement);
	float * tabX = (float*)asterics_malloc(sizeof(float)*nbElement);
	float * tabY = (float*)asterics_malloc(sizeof(float)*nbElement);
	float * tabProba = (float*)asterics_malloc(sizeof(float)*nbElement);
	
	for(long unsigned int i(0lu); i < nbElement; ++i){
		tabX[i] = (float)(i*32lu%17lu);
		tabY[i] = (float)(i*57lu%31lu);
		tabProba[i] = randFloat();
	}
	
	long unsigned int beginTime(rdtsc());
	for(long unsigned int i(0lu); i < nbRepetition; ++i){
		dummyCopy(tabResult, tabX, tabY, tabProba, nbElement, proba);
	}
	long unsigned int elapsedTime((double)(rdtsc() - beginTime)/((double)nbRepetition));
	
	double cyclePerElement(((double)elapsedTime)/((double)nbElement));
	cout << "evaluateDummyCopy : proba = "<<proba<<", nbElement = "<<nbElement<<", cyclePerElement = " << cyclePerElement << " cy/el, elapsedTime = " << elapsedTime << " cy" << endl;
	cerr << proba << "\t" << cyclePerElement << "\t" << elapsedTime << endl;
	
	asterics_free(tabProba);
	asterics_free(tabResult);
	asterics_free(tabX);
	asterics_free(tabY);
}

int main(int argc, char** argv){
	cout << "Branching probability no branching" << endl;
	evaluateDummyCopy(0.1f, 100000lu);
	evaluateDummyCopy(0.2f, 100000lu);
	evaluateDummyCopy(0.3f, 100000lu);
	evaluateDummyCopy(0.4f, 100000lu);
	evaluateDummyCopy(0.5f, 100000lu);
	evaluateDummyCopy(0.6f, 100000lu);
	evaluateDummyCopy(0.7f, 100000lu);
	evaluateDummyCopy(0.8f, 100000lu);
	evaluateDummyCopy(0.9f, 100000lu);
	return 0;
}

