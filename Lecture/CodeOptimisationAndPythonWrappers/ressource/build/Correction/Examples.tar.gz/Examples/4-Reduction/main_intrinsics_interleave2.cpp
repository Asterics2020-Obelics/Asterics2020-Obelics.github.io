/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#include <iostream>
#include "asterics_hpc.h"
#include "reduction_intrinsics_interleave2.h"

using namespace std;

///Get the number of cycles per elements of the reduction
/**	@param nbElement : number of elements of the tables
 * 	@param nbRepetition : number of repetition to evaluate the function reduction
*/
void evaluateReduction(long unsigned int nbElement, long unsigned int nbRepetition){
	float * tabValue = (float*)asterics_malloc(sizeof(float)*nbElement);
	for(long unsigned int i(0lu); i < nbElement; ++i){
		tabValue[i] = (float)(i*32lu%17lu);
	}
	
	long unsigned int beginTime(rdtsc());
	for(long unsigned int i(0lu); i < nbRepetition; ++i){
		reduction(tabValue, nbElement);
	}
	long unsigned int elapsedTime((double)(rdtsc() - beginTime)/((double)nbRepetition));
	
	double cyclePerElement(((double)elapsedTime)/((double)nbElement));
	cout << "evaluateReduction : nbElement = "<<nbElement<<", cyclePerElement = " << cyclePerElement << " cy/el, elapsedTime = " << elapsedTime << " cy" << endl;
	cerr << nbElement << "\t" << cyclePerElement << "\t" << elapsedTime << endl;
	
	asterics_free(tabValue);
}

int main(int argc, char** argv){
	cout << "Reduction intrinsics interleave 2" << endl;
	evaluateReduction(1008lu, 1000000lu);
	evaluateReduction(2000lu, 1000000lu);
	evaluateReduction(3008lu, 1000000lu);
	evaluateReduction(5008lu, 1000000lu);
	evaluateReduction(10000lu, 1000000lu);
	return 0;
}

