/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#ifndef __REDUCTION_INTRINSICS_INTERLEAVE_4_H__
#define __REDUCTION_INTRINSICS_INTERLEAVE_4_H__

float reduction(const float * ptabValue, long unsigned int nbElement);

#endif
