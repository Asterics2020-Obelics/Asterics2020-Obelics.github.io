/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/


#include "reduction.h"

///Do the reduction
/**	@param tabValue : input table
 * 	@param nbElement : number of elements in the input table
 * 	@return sum of all the elements of the input table
*/
float reduction(const float * tabValue, long unsigned int nbElement){
	float res(0.0f);
	for(long unsigned int i(0lu); i < nbElement; ++i){
		res += tabValue[i];
	}
	return res;
}

