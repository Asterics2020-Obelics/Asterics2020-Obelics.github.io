/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#include <immintrin.h>
#include "reduction_intrinsics_interleave2.h"

///Do the Reduction
/**	@param ptabValue : input table
 * 	@param nbElement : number of elements in the input table
 * 	@return sum of all the elements of the input table
*/
float reduction(const float * tabValue, long unsigned int nbElement){
	long unsigned int vecSize(VECTOR_ALIGNEMENT/sizeof(float));
	long unsigned int nbVec(nbElement/(vecSize*2lu));
	float res(0.0f);
	__m256 vecRes1 = _mm256_broadcast_ss(&res);
	__m256 vecRes2 = _mm256_broadcast_ss(&res);
	for(long unsigned int i(0lu); i < nbVec; ++i){
		__m256 vecValue1 = _mm256_load_ps(tabValue + 2lu*i*vecSize);
		vecRes1 = _mm256_add_ps(vecRes1, vecValue1);
		__m256 vecValue2 = _mm256_load_ps(tabValue + (2lu*i + 1lu)*vecSize);
		vecRes2 = _mm256_add_ps(vecRes2, vecValue2);
	}
	__m256 vecRes = _mm256_add_ps(vecRes1, vecRes2);
	float tmp[8lu];
	_mm256_storeu_ps(tmp, vecRes);
	for(long unsigned int i(0lu); i < 8lu; ++i){
		res += tmp[i];
	}
	return res;
}

