/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#ifndef __REDUCTION_VECTORIZE_H__
#define __REDUCTION_VECTORIZE_H__

float reduction(const float * __restrict__ ptabValue, long unsigned int nbElement);

#endif
