/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/


#include "reduction_vectorize.h"

///Do the reduction
/**	@param ptabValue : input table
 * 	@param nbElement : number of elements in the input table
 * 	@return sum of all the elements of the input table
*/
float reduction(const float * __restrict__ ptabValue, long unsigned int nbElement){
	const float* tabValue = (const float*)__builtin_assume_aligned(ptabValue, VECTOR_ALIGNEMENT);
	float res(0.0f);
	for(long unsigned int i(0lu); i < nbElement; ++i){
		res += tabValue[i];
	}
	return res;
}

