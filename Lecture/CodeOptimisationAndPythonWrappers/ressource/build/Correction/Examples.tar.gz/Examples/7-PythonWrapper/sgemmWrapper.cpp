/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#define NO_IMPORT_ARRAY
#ifndef DISABLE_COOL_ARRAY
#define PY_ARRAY_UNIQUE_SYMBOL core_ARRAY_API
#endif

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION

#include <numpy/arrayobject.h>
#include <bytearrayobject.h>

#include "asterics_alloc.h"
#include "allocMatrixWrapper.h"
#include "sgemm_intrinsics_pitch.h"
#include "sgemmWrapper.h"


///Do the SGEMM computation
/**	@param self : parent of the function if it exist
 * 	@param args : arguments passed to the function
 * 	@return result of the SGEMM
*/
PyObject * sgemmWrapper(PyObject *self, PyObject *args){
	PyArrayObject *objMatX = NULL, *objMatY = NULL, *objMatRes = NULL;
	
	if(!PyArg_ParseTuple(args, "OO|O", &objMatX, &objMatY, &objMatRes)){
		PyErr_SetString(PyExc_RuntimeError, "sgemmWrapper : wrong set of arguments. Expect matX, matY [, matRes]\n");
		return NULL;
	}
	if(PyArray_NDIM(objMatX) != 2 || PyArray_NDIM(objMatY) != 2){
		PyErr_SetString(PyExc_TypeError, "sgemmWrapper : input matrix must be a two dimensions array");
		return NULL;
	}
	if(PyArray_DIMS(objMatX)[0] != PyArray_DIMS(objMatX)[1] || PyArray_DIMS(objMatX)[0] != PyArray_DIMS(objMatY)[0] ||
		PyArray_DIMS(objMatY)[0] != PyArray_DIMS(objMatY)[1])
	{
		PyErr_SetString(PyExc_TypeError, "sgemmWrapper : input matrix must be square matrix");
		return NULL;
	}
	long unsigned int sizeMat(PyArray_DIMS(objMatX)[0]);
	
	const float * matX = (const float*)PyArray_DATA(objMatX);
	const float * matY = (const float*)PyArray_DATA(objMatY);
	float * matRes = NULL;
	if(objMatRes != NULL){
		if(PyArray_NDIM(objMatRes) != 2){
			PyErr_SetString(PyExc_TypeError, "sgemmWrapper : input matRes must be a two dimensions array");
			return NULL;
		}
		if(PyArray_DIMS(objMatRes)[0] != PyArray_DIMS(objMatRes)[1] || PyArray_DIMS(objMatRes)[0] != PyArray_DIMS(objMatX)[0]){
			PyErr_SetString(PyExc_TypeError, "sgemmWrapper : matRes must be square matrix with the same size as matX and matY");
			return NULL;
		}
	}else{
		objMatRes = (PyArrayObject*)allocMatrix(sizeMat, sizeMat);
	}
	matRes = (float*)PyArray_DATA(objMatRes);
	
	sgemm(matRes, matX, matY, sizeMat, getPitch(sizeMat));
	
	return (PyObject*)objMatRes;
}

