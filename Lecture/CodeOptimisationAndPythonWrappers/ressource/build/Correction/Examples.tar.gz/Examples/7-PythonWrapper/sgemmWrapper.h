/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#ifndef __SGEMMWRAPPER_H__
#define __SGEMMWRAPPER_H__

#include <Python.h>
#include "structmember.h"

PyObject * sgemmWrapper(PyObject *self, PyObject *args);

#endif
