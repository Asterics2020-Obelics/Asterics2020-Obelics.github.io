#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#ifndef DISABLE_COOL_ARRAY
#define PY_ARRAY_UNIQUE_SYMBOL core_ARRAY_API
#endif

#include <Python.h>
#include "structmember.h"
#include <numpy/arrayobject.h>

#include <string>

#include "allocMatrixWrapper.h"
#include "sgemmWrapper.h"

std::string allocMatrix_docstring = "Allocate a matrix of float with a pitch\n\
Parameters :\n\
	nbRow : number of rows of the matrix\n\
	nbCol : number of columns of the matrix\n\
Return :\n\
	2 dimentional aligned numpy array initialised to 0";

std::string sgemmWrapper_docstring = "Compute a SGEMM with aligned matrix of float32 with a pitch\n\
Parameters :\n\
	matX : left matrix (float32 aligned with a pitch)\n\
	matY : right matrix (float32 aligned with a pitch)\n\
	matRes : Optional argument to avoid result reallocation\n\
Return :\n\
	Result of the SGEMM as numpy array";

static PyMethodDef _asterics_methods[] = {
	{"allocMatrix", (PyCFunction)allocMatrixWrapper, METH_VARARGS, allocMatrix_docstring.c_str()},
	{"sgemm", (PyCFunction)sgemmWrapper, METH_VARARGS, sgemmWrapper_docstring.c_str()},

	{NULL, NULL}
};

static PyModuleDef _asterics_module = {
	PyModuleDef_HEAD_INIT,
	"asterics",
	"",
	-1,
	_asterics_methods,
	NULL,
	NULL,
	NULL,
	NULL
};

///Create the python module asterics
/**	@return python module asterics
*/
PyMODINIT_FUNC PyInit_asterics(void){
	PyObject *m;
	import_array();
	
	m = PyModule_Create(&_asterics_module);
	if(m == NULL){
		return NULL;
	}
	return m;
}

